package com.example.learn_demo_video;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
