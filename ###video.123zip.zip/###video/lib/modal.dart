enum MediaType { image, video }

class MediaItem {
  final String path;
  final MediaType type;
  AnimationType animationType;

  MediaItem({
    required this.path,
    required this.type,
    required this.animationType,
  });
}

enum AnimationType {
  none,
  fadeIn,
  scale,
  rotate,
}
