import 'package:flutter/material.dart';
import 'package:learn_demo_video/home_screen.dart';
import 'package:learn_demo_video/imagecom.dart';
import 'package:learn_demo_video/provider.dart';
import 'package:provider/provider.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => MediaProvider(),
      child: const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: VideoEditorScreen(),
      ),
    );}
  //   return MaterialApp(
  //     title: 'Flutter Demo',
  //     theme: ThemeData(
  //
  //       colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
  //       useMaterial3: true,
  //     ),
  //     home: MyApp()
  //   );
  // }
}


