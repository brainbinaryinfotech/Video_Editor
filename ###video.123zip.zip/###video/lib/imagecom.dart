// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:video_player/video_player.dart';
// import 'package:video_export/video_export.dart';
// import 'package:image_picker/image_picker.dart';
//
// void main() {
//   runApp(MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Video Generation Demo',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: VideoGenerationScreen(),
//     );
//   }
// }
//
// class VideoGenerationScreen extends StatefulWidget {
//   @override
//   _VideoGenerationScreenState createState() => _VideoGenerationScreenState();
// }
//
// class _VideoGenerationScreenState extends State<VideoGenerationScreen> {
//   List<File> selectedImages = [];
//   List<File> selectedVideos = [];
//   VideoPlayerController? _controller;
//
//   @override
//   void initState() {
//     super.initState();
//     _controller = VideoPlayerController.network(
//         'http://www.sample-videos.com/video123/mp4/720/big_buck_bunny_720p_1mb.mp4')
//       ..initialize().then((_) {
//         _controller!.setLooping(true);
//         _controller!.play();
//       });
//   }
//
//   @override
//   void dispose() {
//     super.dispose();
//     _controller!.dispose();
//   }
//
//   Widget buildImagePreview(File image) {
//     return Image.file(image);
//   }
//
//   Widget buildVideoPreview(File video) {
//     return VideoPlayer(_controller!);
//   }
//
//   Future<void> pickImage() async {
//     final XFile? image =
//     await ImagePicker().pickImage(source: ImageSource.gallery);
//     if (image != null) {
//       setState(() {
//         selectedImages.add(File(image.path));
//       });
//     }
//   }
//
//   Future<void> pickVideo() async {
//     final XFile? video =
//     await ImagePicker().pickVideo(source: ImageSource.gallery);
//     if (video != null) {
//       setState(() {
//         selectedVideos.add(File(video.path));
//       });
//     }
//   }
//   //
//   // Future<void> generateVideo() async {
//   //   final exporter = VideoExporter();
//   //   await exporter.createComposition();
//   //
//   //   for (File image in selectedImages) {
//   //     await exporter.addImageToComposition(image);
//   //   }
//   //
//   //   for (File video in selectedVideos) {
//   //     await exporter.addVideoToComposition(video);
//   //   }
//   //
//   //   final File outputVideo = await exporter.exportToMp4();
//   //   // You can use the outputVideo file as needed
//   //
//   //   // Display the generated video
//   //   _controller = VideoPlayerController.file(outputVideo)
//   //     ..initialize().then((_) {
//   //       _controller!.setLooping(true);
//   //       _controller!.play();
//   //     });
//   // }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Video Generation Demo'),
//       ),
//       body: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: <Widget>[
//           ElevatedButton(
//             onPressed: pickImage,
//             child: Text('Pick Image'),
//           ),
//           ElevatedButton(
//             onPressed: pickVideo,
//             child: Text('Pick Video'),
//           ),
//           ElevatedButton(
//             onPressed: generateVideo,
//             child: Text('Generate Video'),
//           ),
//           SizedBox(height: 20),
//           if (selectedImages.isNotEmpty)
//             Expanded(
//               child: ListView.builder(
//                 itemCount: selectedImages.length,
//                 itemBuilder: (context, index) =>
//                     buildImagePreview(selectedImages[index]),
//               ),
//             ),
//           if (selectedVideos.isNotEmpty)
//             Expanded(
//               child: ListView.builder(
//                 itemCount: selectedVideos.length,
//                 itemBuilder: (context, index) =>
//                     buildVideoPreview(selectedVideos[index]),
//               ),
//             ),
//         ],
//       ),
//     );
//   }
// }
